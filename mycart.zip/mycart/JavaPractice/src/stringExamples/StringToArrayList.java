package stringExamples;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
public class StringToArrayList
{
    public static void main(String args[])
    {
	String num = "22,33,44,55,66,77";
	String n = "abc,xyz,pqr,stu,mno";
	
	String str[] = num.split(",");
	String str1[] = n.split(",");
	
	//creating an arraylist
	List<String> al = new ArrayList<String>();
	List<String> a2 = new ArrayList<String>();
	
	//converting string to arraylist
	al = Arrays.asList(str);
	a2 = Arrays.asList(str1);
	
	//for-each loop
	for(String s: al)
	{
	   System.out.print(s + " "); 
	}
	 System.out.println(" "); 
	for(String s1: a2)
	{
	   System.out.print(s1 + " ");
	}
   }
}