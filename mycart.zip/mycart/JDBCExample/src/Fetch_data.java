import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Fetch_data 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Statement stmt;
		ResultSet rs;
		Connection con;

		
		try
		{
			ConnectionProgram c=new ConnectionProgram();
			c.Connection();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded Successfully");
			con=DriverManager.getConnection(url, un, pw);
		}

	}

}
