package stringExamples;
public class StringReverse {
public static void main(String[] args) {
// TODO Auto-generated method stub
String str = "Welcome to Bengaluru";
String[] strArray = str.split(" ");
for (String temp: strArray){
System.out.println(temp);
}
for(int i=0; i<3; i++)
{ 
	char[] s1 = strArray[i].toCharArray(); 
	for (int j = s1.length-1; j>=0; j--)
	{
		System.out.print(s1[j]);
	}
	System.out.print(" ");
}
/*char y[]=str.toCharArray();
int size=y.length;
char a[]=new char[size];
int i=0;
while(i!=size)
{
	a[size-1-i]=y[i];
	i++;
}
System.out.println(str);
System.out.println(a);*/
}
}