package stringExamples;

public class RightPaddingExample 
{
	  public static void main(String[] argv)
	  {
	    System.out.println("#" + rightPadding("mystring", 10) + "@");
	    System.out.println("#" + rightPadding("mystring", 15) + "@");
	    System.out.println("#" + rightPadding("mystring", 20) + "@"); 
	  }

	  public static String rightPadding(String str, int num) 
	  {
	    return String.format("%1$-" + num + "s", str);
	  }
	}