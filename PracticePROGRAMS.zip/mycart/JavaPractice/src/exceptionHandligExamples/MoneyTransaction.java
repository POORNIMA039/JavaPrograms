package exceptionHandligExamples;

import java.util.Scanner;

public class MoneyTransaction 
{
	final int accountNumber=123456;
	final int password=4549;
	private int pwd;
	private int acc_num;
	Scanner s=new Scanner(System.in);
	void input()
	{
	System.out.println("Enter the account number ");
	acc_num=s.nextInt();
	System.out.println("Enter the password ");
	pwd=s.nextInt();
	}
	void validation() throws InvalidCustomerException
	{
		if(acc_num==accountNumber && pwd==password)
		{
			System.out.println("Enter the amount");
			int amount=s.nextInt();
			System.out.println("Thank you!!!!!Please collecct the money");
		}
		else
		{
			InvalidCustomerException ice=new InvalidCustomerException();
			System.out.println(ice.getMessage());
			throw ice;
		}
	}
	
}
