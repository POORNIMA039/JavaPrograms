package polymorphism;

public class FighterPlane extends Plane 
{
	void fly()
	{
		System.out.println("FighterPlane is flying at higher altitude ");
	}
}
