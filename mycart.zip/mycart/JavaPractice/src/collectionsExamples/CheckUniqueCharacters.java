package collectionsExamples;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CheckUniqueCharacters 
{
	public static void main(String[] args)
	{
		String str1="Hello World";
		char y[]=str1.toCharArray();
		int size=y.length;
		int i=0;
		Map<Character,Integer> map=new HashMap<>();
		
		while(i!=size)
		{
			if(map.containsKey(y[i])==false)
			{
				map.put(y[i], 1);
			}
			else
			{
				int oldvalue=map.get(y[i]);
				int newvalue=oldvalue+1;
				map.put(y[i], newvalue);
			}
			++i;
		}
		
		Set<Map.Entry<Character,Integer>> hmap=map.entrySet();
		for(Map.Entry<Character,Integer> data:hmap)
			{
				if(data.getValue()>1)
				{
					System.out.println("All characters are not unique");
					System.exit(0);
				}
				else
				{
					System.out.println("All characters are unique");
					System.exit(0);
				}
			}
	}

}
