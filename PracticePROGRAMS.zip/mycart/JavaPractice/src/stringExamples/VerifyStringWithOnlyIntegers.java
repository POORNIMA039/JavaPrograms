package stringExamples;

public class VerifyStringWithOnlyIntegers 
{
	public static void main(String[] args)
	{
		String str="97ab";
		
		int size=str.length();
		int i=0;
		
		while(i!=size)
		{
			if(str.charAt(i)>='0'&&str.charAt(i)<='9')
			{
				++i;
			}
			else
			{
				System.out.println("Not an integer String");
				System.exit(0);
			}
		}
		System.out.println(" Integer String");
	}
}
