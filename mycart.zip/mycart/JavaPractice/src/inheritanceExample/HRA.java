package inheritanceExample;

class HRA extends Faculty
{  
float hra=3000;  
} 