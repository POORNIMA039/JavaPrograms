package stringExamples;

import java.util.Scanner;

public class CopyingStringToString
{
	public static void main(String[] args)
	{
	String str;
	int i=0;
	System.out.println("Enter String---");
	Scanner s=new Scanner(System.in);
	str=s.nextLine();
	char y[]=str.toCharArray();
	int size=y.length;
	///System.out.println(size);
	char x[]=new char[size];
	while(i!=size)
	{
		x[i]=y[i];
		++i;
	}
	System.out.println("------------------------");
	System.out.println(x);
	} 
}
