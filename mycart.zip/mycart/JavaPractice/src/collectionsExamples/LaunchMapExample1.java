package collectionsExamples;

public class LaunchMapExample1 
{
    // Driver Code 
    public static void main(String args[]) 
    { 
    	MapExample1 me1=new MapExample1();
    	me1.insert();
        me1.sortbykey(); 
    } 

}
