package exceptionHandligExamples;

import java.util.InputMismatchException;

public class LaunchExample2 
{
	public static void main(String[] args)
	{
		try
		{
		System.out.println("CONNECTION ESTABLISHED");
		Example2 e2=new Example2();
		e2.execute();
		}
		catch(NegativeArraySizeException nase)
		{
			System.out.println("please enter the positive number");
		}
		catch(InputMismatchException ime)
		{
			System.out.println("please enter element of valid type");
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("please enter the position valuse less than the array size");
		}
		catch(Exception e)
		{
			System.out.println("Some other problem");
		}
		finally
		{
			System.out.println("CONNECTION TERMINATED");
		}
	}
}
