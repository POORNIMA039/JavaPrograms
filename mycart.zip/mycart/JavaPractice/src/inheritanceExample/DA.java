package inheritanceExample;

class DA extends HRA
{  
float da=2000;  
} 
