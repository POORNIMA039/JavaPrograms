package collectionsExamples;

class Student
{  
	  String usn;  
	  String name;  
	  int semester;  
	  Student(String usn,String name,int semester)
	  {  
	   this.usn=usn;  
	   this.name=name;  
	   this.semester=semester;  
	  }  
	} 