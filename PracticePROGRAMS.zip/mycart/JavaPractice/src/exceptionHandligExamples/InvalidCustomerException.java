package exceptionHandligExamples;

public class InvalidCustomerException extends Exception
{
	public String getMessage()
	{
		return "Invalid Customer";
	}
}
