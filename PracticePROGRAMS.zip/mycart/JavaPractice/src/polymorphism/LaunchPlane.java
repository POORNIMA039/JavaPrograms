package polymorphism;

public class LaunchPlane
{
	public static void main(String[] args) 
	{
		CargoPlane cp=new CargoPlane();
		PassengerPlane pp=new PassengerPlane();
		FighterPlane fp=new FighterPlane();
		Airport a=new Airport();
		
		a.permit(cp);
		System.out.println("-------------");
		a.permit(cp);
		System.out.println("-------------");
		a.permit(cp);

	}

}
