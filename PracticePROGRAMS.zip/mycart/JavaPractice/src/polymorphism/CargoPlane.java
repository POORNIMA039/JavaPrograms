package polymorphism;

public class CargoPlane extends Plane 
{
	void fly()
	{
		System.out.println("CargoPlane is flying at lower altitude ");
	}
}
