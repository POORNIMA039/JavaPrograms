package inheritanceExample; 

class Launch extends DA
{ 
	float bonous=2000;
	public static void main(String args[])
	{
		Launch obj=new Launch(); 
		obj.total_sal=obj.salary+obj.hra+obj.da+obj.bonous;
		System.out.println("Total Salary is:"+obj.total_sal);   
	}  
}