package stringExamples;

import java.util.Scanner;
//without using the inbuilt method
public class LegnthOfString 
{

	public static void main(String[] args) 
	{
		String str;
		int count=0;
		int i=0;
		System.out.println("Enter String---");
		Scanner s=new Scanner(System.in);
		str=s.nextLine();
		str=str.concat("\0");
		char y[]=str.toCharArray();
		
		while(y[i]!='\0')
		{
			++count;
			++i;
		}
		System.out.println("Length of a string" + " " +count);

	}

}
