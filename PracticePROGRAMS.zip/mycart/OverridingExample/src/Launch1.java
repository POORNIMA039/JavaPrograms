
public class Launch1 
{

	public static void main(String[] args) 
	{
		CargoPlane c=new CargoPlane();
		PassengerPlane p=new PassengerPlane();
		FighterPlane f=new FighterPlane();
        
		Airport a=new Airport();
		
		a.permit(c);
		a.permit(p);
		a.permit(f);
	}

}


class Plane
{
	void takeOff()
	{
		System.out.println("Plane is taking off");
	}
	
	void fly()
	{
		System.out.println("Plane is flying");
	}
	
	void land()
	{
		System.out.println("Plane is landing");
		System.out.println("-----------------");
	}
}

class CargoPlane extends Plane
{
	void fly()
	{
		System.out.println("CargoPlane is flying at lower altitude");
	}
}

class PassengerPlane extends Plane
{
	void fly()
	{
		System.out.println("PassengerPlane is flying at medium altitude");
	}
}

class FighterPlane extends Plane
{
	void fly()
	{
		System.out.println("FighterPlane is flying at higher altitude");
	}
}

class Airport
{
	void permit(Plane ref)
	{
		ref.takeOff();
		ref.fly();
		ref.land();
	}
}
