
public class Example2 
{

	public static void main(String[] args) 
	{
        /*sum of two numbers
		int a=74, b=36;
		int sum;
		
		sum=(a+b);
		
		System.out.println("Sum :" + sum);*/
		
		//division of two numbers
		 
		 int a=50,b=3;
		 
		 int div;
		 
		 div=a/b;
		 
		 System.out.println("RESULT :" + div);
		 
		 
	}

}
