package encapsulationExample;

import java.util.Scanner;

public class Bank 
{
	public static void main(String[] args)
	{
		SettingAccountDetails sd = new SettingAccountDetails();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the details(Name,age,contactNumber,AccountNumber):");
		String name=s.nextLine();
		int age=s.nextInt();
		String phNum=s.next();
		String accNum=s.next();
		
		//setting the values
		sd.setAccountHolderName(name);
		sd.setAge(age);
		sd.setContactNumber(phNum);
		sd.setAccountNumber(accNum);
		
		System.out.println("Account Details Successfully filled");
		System.out.println("Details:");
		//displaying the details
		System.out.println("AccountHolderName:" + " " + sd.getAccountHolderName());
		System.out.println("Age:" + " " + sd.getAge());
		System.out.println("ContactNumber:" + " " + sd.getContactNumber());
		System.out.println("AccountNumber:" + " " + sd.getAccountNumber());
	}
}
