package basicPrograms;

public class CountingNumberOfInstance 
{
	public static void main(String []args)
	{
		Count c= new Count();
		System.out.println(Count.count);
		Count c1= new Count();
		System.out.println(Count.count);
		Count c2= new Count();
		System.out.println(Count.count);
		Count c3= new Count();
		System.out.println(Count.count);
	}
}



class Count
{
	static int count;
	//non static block
	{
		count++;
	}
	
	Count()
	{
		
	}
}