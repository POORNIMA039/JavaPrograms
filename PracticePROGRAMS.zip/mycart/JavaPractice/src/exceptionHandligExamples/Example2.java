package exceptionHandligExamples;

import java.util.*;

public class Example2 
{
	void execute()
	{
	Scanner s=new Scanner(System.in);
	
	System.out.println("Enter the size of an array");
	int size=s.nextInt();
	int a[]=new int[size];
	System.out.println("Enter the element to be inserted");
	int element=s.nextInt();
	System.out.println("Enter the position where element must be inserted");
	int position=s.nextInt();
	a[position]=element;
	System.out.println("Value inserted successfully");
		/*catch(NegativeArraySizeException nase)
		{
			System.out.println("please enter the positive number");
		}
		catch(InputMismatchException ime)
		{
			System.out.println("please enter element of valid type");
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("please enter the position valuse less than the array size");
		}
		catch(Exception e)
		{
			System.out.println("Some other problem");
		}
		*/
	}
	
}
