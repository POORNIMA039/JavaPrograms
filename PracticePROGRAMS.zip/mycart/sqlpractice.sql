create database sqlpractice;
use sqlpractice;

--creation of table 
create table department (dept_id int primary key, dept_name varchar(20),
loc varchar(10));


insert into department values('1','cs','blore');
insert into department values('2','ece','blore');
insert into department values('3','civ','blore');
insert into department values('4','mech','blore');



show tables;


create table student (usn integer Primary key, st_name varchar(10) ,
st_marks int, dept_id int, foreign key (dept_id)
 references department(dept_id) );


 /* inserstion into table */
insert into student values ('0012','anu','77','1');
insert into student values ('0018','sanu','69','2');
insert into student values ('0016','anil','53','2');
insert into student values ('0013','anusha','79','3');

 select * from student;

--creation of table from another table 
CREATE TABLE TestTable1 AS
SELECT st_name, usn
FROM student;


--alteration of table adding new column
ALTER TABLE testtable1
ADD class int;


--alteration of table to drop column 
ALTER TABLE testtable1
DROP COLUMN class;


--alteration of table to modify column 
ALTER TABLE testable
MODIFY COLUMN usn varchar(10);


-- constraints

CREATE TABLE employee (
    first_name varchar(10) not null unique ,
    last_name varchar(10),
    id int primary key ,
    age int check(age>18) );

CREATE TABLE employee1 (
    first_name varchar(10) ,
    last_name varchar(10),
    id int primary key ,
    age int );


insert into employee1 values ('John','R','2','29');
insert into employee1 values ('Jonny','S','3','36');
insert into employee1 values ('David','D','1','35');



--update 
UPDATE employee1
SET first_name = 'Peter'
WHERE ID = 1;

--selection and projection

select 'rock' from dual;
select * from employee1;
select * from student where usn = 0012;

-- pipe operator
select first_name ||' '|| last_name 
from employee1;

--where clause 
select *
from student
where dept_id = 2;

select * from student where st_marks>50;

--distinct keyword
select distinct dept_id
from student;

--like operator 
select first_name ,last_name
from employee1
where last_name like '%D%'or first_name like 'h%';

--between and not in between  
select * from student where st_marks between 35 and 80;
select * from student where st_marks not between 35 and 80;

--In 
select * from student where st_marks in(35,79);

--Not In
 select * from student where st_marks not in(35,79);

--IS  Null and Is not Null
select * from student where st_marks is not null;
select * from student where st_marks is null;

--case manipuplation
select Upper(first_name),lower(first_name)from employee1;

--Charcter  manipuplation
select concat(first_name,last_name) from employee1;
select concat(first_name,concat(' ',last_name)) from employee1;

select length(first_name) from employee1;

select substr('ManMohanSingh',9,3) from dual;
select instr(first_name,'i') from employee1;

select trim('C' from 'Colour') from dual;
select trim('  Colour   ') from dual;

select replace('karnataka','k','K') from dual;
select replace('Beautiful','ful','100')from dual;

select reverse(first_name) from employee1;

--number function
select round(86745.86574,2) from dual;
select round(86745.86574,-2) from dual;

select truncate(86745.86574,2) from dual;
select truncate(86745.86574,-2) from dual;

select mod(693,3) from dual;

select power(693,3) from dual;

select sqrt(625) from dual;

-- Multi-Row Function
select max(st_marks) from student;
select min(st_marks) from student;
select sum(st_marks) from student;
select avg(st_marks) from student;
select count(*) from student;

--order by
SELECT * FROM employee1 ORDER BY last_name;

--nested query
select * from student where dept_id = (select dept_id from department where dept_name = 'civ');
 
--group by
SELECT COUNT(*), first_name FROM employee1
GROUP BY first_name
ORDER BY first_name DESC;

--having
SELECT COUNT(*), first_name FROM employee1
GROUP BY first_name
HAVING COUNT(*) > 1
ORDER BY first_name DESC;

--joins
SELECT *
FROM student s
INNER JOIN department d
ON s.dept_id = d.dept_id;

SELECT *
FROM student s
left JOIN department d
ON s.dept_id = d.dept_id;

SELECT *
FROM student s
right JOIN department d
ON s.dept_id = d.dept_id;




