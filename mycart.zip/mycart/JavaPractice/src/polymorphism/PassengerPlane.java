package polymorphism;

public class PassengerPlane extends Plane 
{
	void fly()
	{
		System.out.println("PassengerPlane is flying at medium altitude ");
	}
}
