package stringExamples;

import java.util.Scanner;

public class PalindromeCheck1 
{
	 public static void main(String[] args)
	 {
		 String str;
		 int i=0,size;
		 Scanner s=new Scanner(System.in);
		 System.out.println("enter the string");
		 str=s.nextLine();
		// str=str.replace(" " , "");
		 //str=str.toUpperCase();
		 char y[]=str.toCharArray();
		 size=y.length;
		 char x[]=new char[size];
		 //reversing a string
		 while(i!=size)
		 {
			 x[size-1-i]=y[i];
			 ++i;
		 }
		 System.out.println(x);
		 //palindrome check
		 i=0;
		 while(i!=size)
		 {
			 if(x[i]!=y[i])
			 {
				 System.out.println("Not a palindrome"); 
				 System.exit(0);
			 }
			 else
			 {
				 ++i;
				 continue;
			 }
		 }
		 System.out.println("palindrome");
	 }
}
