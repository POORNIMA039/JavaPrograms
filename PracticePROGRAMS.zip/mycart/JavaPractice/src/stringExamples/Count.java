package stringExamples;

public class Count 
{
	int x,y,count;
	Count()
	{
		super();
		{
			count++;
		}
	}
	
	Count(int x,int y)
	{
		count++;
		this.x=x;
		this.y=y;
		
	}

}
