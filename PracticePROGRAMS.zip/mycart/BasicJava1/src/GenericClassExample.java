
class TestClass<T> 
{ 
    // An object of type T is declared 
    T obj; 
    TestClass(T obj) 
    {  
    	this.obj = obj; 
    } 
    // constructor 
    public T getObject() 
    {
    	return this.obj; 
    	} 
} 
   
// Driver class to test above 
class GenericClassExample 
{ 
    public static void main (String[] args) 
    { 
        // instance of Integer type 
    	TestClass <Integer> iObj = new TestClass<Integer>(100); 
        System.out.println(iObj.getObject()); 
   
        // instance of String type 
        TestClass <String> sObj = new TestClass<String>("Testing Class"); 
        System.out.println(sObj.getObject()); 
    } 
}