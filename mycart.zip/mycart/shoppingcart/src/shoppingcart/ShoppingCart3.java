package shoppingcart;

public class ShoppingCart3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Item item =new Item();
     
    if(item.setColor('B'))
    	System.out.println("item.color = "+ item.color);
    
    else
    	System.out.println("invalid code");
	}

}
