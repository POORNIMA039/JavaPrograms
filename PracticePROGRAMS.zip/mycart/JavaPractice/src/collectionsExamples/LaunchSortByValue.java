package collectionsExamples;

public class LaunchSortByValue 
{
	public static void main(String[] args)   
	{   
	SortByValue sv = new SortByValue();  
	sv.createMap();  
	System.out.println("Sorting values in ascending order:");  
	sv.sortByValue(true);  
	System.out.println("Sorting values in  descending order");  
	sv.sortByValue(false);  
	}
}
