package stringExamples;

public class IntegerToString 
{
	   public static void main(String args[])
	   {
		int num = 111;
		
		//converting integer to string
		String str = String.valueOf(num);
		String str1 = Integer.toString(num);
		String str2 = String.format("%d", num);
		
		System.out.println("String is: "+str);
		
		//output is: 555111 because the str is a string 
		//and the + would concatenate the 555 and str
		System.out.println("RESULT1:" + 555+str);
		System.out.println("RESULT2:" + 555+str1);
		System.out.println("RESULT3:" + 555+str2);
		
		//output is: 666 because num is int value and the
        //+ would perform the addition of 555 and num
	     System.out.println(555+num);
		
	   }
}