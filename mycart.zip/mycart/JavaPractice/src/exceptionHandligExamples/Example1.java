package exceptionHandligExamples;

import java.util.Scanner;

//handling an exception using try-catch block

public class Example1 
{
	public static void main(String[] args) 
	{
	    Demo d = new Demo();
	    d.calc();
	}

}

class Demo
{
	void calc()
	{
		System.out.println("CONNECTION ESTABLISHED");
		Scanner s = new Scanner(System.in);
		System.out.println("----Division of two numbers----");
		try
		{
			
		System.out.println("Enter the numerator");
		int numerator = s.nextInt();
		System.out.println("Enter the denominator");
		int denominator = s.nextInt();
		
		int result = (numerator/denominator);
		
		System.out.println("RESULT : " + result);
		}
		
		catch(ArithmeticException ae)
		{
			System.out.println("Denominator cannot be zero!!!!!!");
		}
		
		catch(Exception e)
		{
			System.out.println("Some problem,Please check the inputs");
		}
		
		System.out.println("CONNECTION TERMINATED");
		
		
	}
}