
 class Animals 
 {
	void live()
	{
		System.out.println("Animals lives on the earth");
	}
}

class WildAnimals extends Animals
{
	void live()
	{
		System.out.println("Wild animals lives in the forest");
	}
}

class DomesticAnimals extends Animals
{
	void live()
	{
		System.out.println("Domestic animals donot live in forest");
	}
}



class Launch
{
	public static void main(String[] args)
	{
		
	WildAnimals wa= new WildAnimals();
	DomesticAnimals da= new DomesticAnimals();
	
		
	wa.live();
	da.live();
	}
}