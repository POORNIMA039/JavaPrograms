package exceptionHandligExamples;

public class Bank
{
	public static void main(String[] args) 
	{
		MoneyTransaction mt=new MoneyTransaction();
		try
		{
			mt.input();
			mt.validation();
		}
		catch(Exception e)
		{
			try
			{
				mt.input();
				mt.validation();
			}
			catch(Exception e1)
			{
				try
				{
					mt.input();
					mt.validation();
				}
				catch(Exception e2)
				{
					System.out.println("Sorry!!!!Your card is blocked");
					System.out.println("For further queries visit your nearest bank");
					System.exit(0);
				}
			}
		}
		
	}

}
