package stringExamples;

public class StringToInteger 
{
	public static void main(String []args)
	{
	String str="543",str1="-123";
	int num=123;
	int num1,num2,result;
	
	//converting string into integer using parseInt()
	num1=Integer.parseInt(str);
	
	//converting string into integer using valueOf()
	num2=Integer.valueOf(str1);
	
	result=num + num1;
	System.out.println(num1);
	System.out.println("Result1:"+result);
	
	result=num + num2;
	System.out.println(num2);
	System.out.println("Result2:"+result);
	
	}
}
