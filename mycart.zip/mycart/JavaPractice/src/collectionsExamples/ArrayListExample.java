package collectionsExamples;

import java.util.*;  
class ArrayListExample{  
public static void main(String args[])
{  
 //Creating user-defined class objects  
 Student s1=new Student("aa021","Ramu",8);
 Student s2=new Student("aa085","Yashu",5);
 Student s3=new Student("aa012","Chandu",7); 
 
 //creating arraylist  
 ArrayList<Student> al=new ArrayList<Student>();  
 al.add(s1);//adding Student class object  
 al.add(s2);  
 al.add(s3);  
 
 //Getting Iterator  
 Iterator itr=al.iterator();  
 //traversing elements of ArrayList object  
 while(itr.hasNext())
 {  
   Student st=(Student)itr.next();  
   System.out.println(st.usn+" "+st.name+" "+st.semester);  
 }  
}  
}  