package polymorphism;

public abstract class Plane 
{
	final void takeOff()
	{
		System.out.println("plane is taking off ");
	}
	abstract void fly(); 
	final void land()
	{
		System.out.println("Plane is landing ");
	}
}
