import java.util.Scanner;
public class Example6{
     public static void main(String[] args) {
    	 int input_first_number,input_second_number;
    	 Scanner s = new Scanner(System.in);
    	 System.out.println("Enter two numbers");
    	 input_first_number=s.nextInt();
    	 input_second_number=s.nextInt();
    	 System.out.println("input_first_number :"+input_first_number);
    	 System.out.println("input_second_number :"+input_second_number);
    	 System.out.println(input_first_number+input_second_number);
    	 System.out.println(input_first_number*input_second_number);
    	 System.out.println(input_first_number-input_second_number);
    	 System.out.println(input_first_number/input_second_number);
    	 System.out.println(input_first_number%input_second_number);
     }}
