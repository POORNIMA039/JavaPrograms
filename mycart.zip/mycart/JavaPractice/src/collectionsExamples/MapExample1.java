package collectionsExamples;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

class MapExample1
{ 
	   
    static Map<String, Integer> map = new HashMap<>(); 
    void insert()
    {
    map.put("Jayant", 80); 
    map.put("Abhishek", 90); 
    map.put("Anushka", 80); 
    map.put("Amit", 75); 
    map.put("Danish", 40);
    }
    //sorting
    public static void sortbykey() 
    { 
        // TreeMap to store values of HashMap 
        TreeMap<String, Integer> sorted = new TreeMap<>(); 
  
        // Copy all data from hashMap into TreeMap 
        sorted.putAll(map); 
  
        // Display the TreeMap which is naturally sorted 
        for (Map.Entry<String, Integer> entry : sorted.entrySet())  
        {
            System.out.println("Key = " + entry.getKey() +  ", Value = " + entry.getValue());  
        }
    } 
} 