import java.sql.*;

public class ConnectionProgram 
{
	public static void main(String[] args)
	{
//		String url="jdbc:oracle:thin:@//localhost:1521/XE";
//		String un="root";
//		String pw="root";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded Successfully");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
