package stringExamples;

import java.util.Arrays;
import java.util.Scanner;

public class AnagramCheck 
{
	public static void main(String[] args)
	{
		 String str1,str2;
		 Scanner s=new Scanner(System.in);
		 System.out.println("enter the first string");
		 str1=s.nextLine();
		 char x[]=str1.toCharArray();
		 System.out.println("enter the second string");
		 str2=s.nextLine();
		 str1=str1.replace(" " , "");
		 str1=str1.toUpperCase();
		 str2=str2.replace(" " , "");
		 str2=str2.toUpperCase();
		 char y[]=str2.toCharArray();
		 //sorting
		 Arrays.sort(x);
		 Arrays.sort(y);
		 
		 Boolean result=Arrays.equals(x, y);
		 if(result==true)
			 System.out.println("It is a anagram"); 
		 else
			 System.out.println("It is not a anagram");
	}
}
