package polymorphism;

public class Airport
{
 void permit(Plane ref)
{
	 ref.takeOff();
	 ref.fly();
	 ref.land();
}
}