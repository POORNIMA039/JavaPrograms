
public class Launch2
{

	public static void main(String[] args)
	{
		Demo1 d1=new Demo1();
		d1.fun();

	}

}

 
class Demo1 implements Demo
{
	public void fun()
	{
		System.out.println("Inside Demo1");
	}

	@Override
	public void disp() {
		// TODO Auto-generated method stub
		
	}
}

interface Demo
{
	void fun();
	void disp();
}