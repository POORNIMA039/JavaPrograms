package inheritanceExample;

class Faculty
{  
float total_sal=0, salary=30000;  
} 
