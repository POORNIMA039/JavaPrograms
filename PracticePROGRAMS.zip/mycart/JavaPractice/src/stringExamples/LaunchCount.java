package stringExamples;



public class LaunchCount {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Count c=new Count();
		System.out.println(c.count);
		
		Count c1=new Count(2,3);
		System.out.println(c1.count);

	}

}
