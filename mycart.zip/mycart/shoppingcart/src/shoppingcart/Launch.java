package shoppingcart;

public class Launch {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		Calculator c= new Calculator();
		int result=c.add(2,3);
		System.out.println("ADDITION RESULT: " + " " + result);
		
		int result1=c.sub(5,3);
		System.out.println("SUBTRACTION RESULT: " + " " + result1);
		
		int result2=c.mul(2,3);
		System.out.println("MULTIPLICATION RESULT: " + " " + result2);
		
		int result3=c.div(21,3);
		System.out.println("DIVISION RESULT: " + " " + result3);
	}

}
